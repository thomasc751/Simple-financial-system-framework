import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Project, ProjectStatus, ProjectType, STATUS_LABELS, TYPE_LABELS, STATUS_COLORS, PRIORITY_LABELS, PRIORITY_COLORS } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';

interface DashboardProps {
  projects: Project[];
}

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#6366f1'];

export const Dashboard: React.FC<DashboardProps> = ({ projects }) => {
  const navigate = useNavigate();
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState('');

  // --- Statistics Logic ---
  const statusData = Object.values(ProjectStatus).map(status => ({
    name: STATUS_LABELS[status],
    value: projects.filter(p => p.status === status).length
  })).filter(d => d.value > 0);

  const typeData = Object.values(ProjectType).map(type => ({
    name: TYPE_LABELS[type].substring(0, 4),
    fullName: TYPE_LABELS[type],
    count: projects.filter(p => p.type === type).length,
    budget: projects.filter(p => p.type === type).reduce((sum, p) => sum + p.budget, 0)
  })).filter(d => d.count > 0);

  const totalBudget = projects.reduce((acc, curr) => acc + curr.budget, 0);

  // --- Filtering Logic ---
  const filteredProjects = projects.filter(p => {
    const matchesSearch = p.title.includes(searchTerm) || p.id.includes(searchTerm) || p.applicantName.includes(searchTerm);
    let matchesStatus = true;

    if (filterStatus === 'PENDING') {
      matchesStatus = p.status === ProjectStatus.PENDING || p.status === ProjectStatus.REVIEWING;
    } else if (filterStatus === 'ACTIVE') {
      matchesStatus = p.status === ProjectStatus.APPROVED || p.status === ProjectStatus.IN_PROGRESS;
    } else if (filterStatus === 'COMPLETED') {
      matchesStatus = p.status === ProjectStatus.COMPLETED;
    } else if (filterStatus === 'ISSUES') {
      matchesStatus = p.status === ProjectStatus.PAUSED || p.status === ProjectStatus.REJECTED;
    }
    
    return matchesSearch && matchesStatus;
  });

  // Custom Tooltip for Charts
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-slate-200 shadow-lg rounded-lg text-sm z-50">
          <p className="font-bold text-slate-700 mb-1">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }}>
              {entry.name === 'Count' ? '数量' : entry.name === 'Budget' ? '预算' : entry.name}: 
              {typeof entry.value === 'number' && (entry.name === 'Budget' || entry.dataKey === 'budget')
                ? ` ¥${entry.value.toLocaleString()}` 
                : ` ${entry.value}`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-8 animate-fade-in pb-10">
      
      {/* 1. KPI Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 relative overflow-hidden group hover:shadow-md transition">
            <div className="absolute right-0 top-0 w-24 h-24 bg-blue-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
            <div className="relative z-10">
                <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">工程委托总数</p>
                <h3 className="text-3xl font-extrabold text-slate-800 mt-2">{projects.length}</h3>
                <p className="text-green-600 text-xs mt-2 flex items-center"><i className="fa-solid fa-arrow-trend-up mr-1"></i> 业务总量</p>
            </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 relative overflow-hidden group hover:shadow-md transition">
            <div className="absolute right-0 top-0 w-24 h-24 bg-orange-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
            <div className="relative z-10">
                <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">待审核/处理</p>
                <h3 className="text-3xl font-extrabold text-orange-500 mt-2">{projects.filter(p => p.status === ProjectStatus.PENDING || p.status === ProjectStatus.REVIEWING).length}</h3>
                <p className="text-slate-400 text-xs mt-2">需尽快响应</p>
            </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 relative overflow-hidden group hover:shadow-md transition">
            <div className="absolute right-0 top-0 w-24 h-24 bg-indigo-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
            <div className="relative z-10">
                <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">正在施工/执行</p>
                <h3 className="text-3xl font-extrabold text-indigo-600 mt-2">{projects.filter(p => p.status === ProjectStatus.IN_PROGRESS || p.status === ProjectStatus.APPROVED).length}</h3>
                <p className="text-slate-400 text-xs mt-2">现场作业中</p>
            </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 relative overflow-hidden group hover:shadow-md transition">
             <div className="absolute right-0 top-0 w-24 h-24 bg-emerald-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110"></div>
            <div className="relative z-10">
                <p className="text-slate-500 text-xs font-bold uppercase tracking-wider">总预算估值</p>
                <h3 className="text-3xl font-extrabold text-emerald-600 mt-2">¥{(totalBudget / 10000).toFixed(1)}万</h3>
                <p className="text-slate-400 text-xs mt-2">本年度累计</p>
            </div>
        </div>
      </div>

      {/* 2. Interactive Project List (The Core Fix) */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        {/* Header & Controls */}
        <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h3 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                    <i className="fa-solid fa-list-ul text-municipal-600"></i> 项目电子台账
                </h3>
                <p className="text-sm text-slate-500 mt-1">查看、管理所有工程项目的详细状态与进度</p>
            </div>
            <div className="flex flex-col md:flex-row gap-3">
                <div className="relative">
                    <i className="fa-solid fa-search absolute left-3 top-3 text-slate-400 text-sm"></i>
                    <input 
                        type="text" 
                        placeholder="搜索项目名称/ID/申请人..." 
                        className="pl-9 pr-4 py-2 border rounded-lg text-sm w-full md:w-64 focus:ring-2 focus:ring-municipal-500 outline-none transition"
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                    />
                </div>
                <button className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-sm font-bold transition flex items-center gap-2">
                    <i className="fa-solid fa-filter"></i> 更多筛选
                </button>
            </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-100 bg-slate-50/50">
            {[
                { key: 'ALL', label: '全部项目', icon: 'fa-layer-group' },
                { key: 'PENDING', label: '待审核/立项', icon: 'fa-clock' },
                { key: 'ACTIVE', label: '执行中', icon: 'fa-person-digging' },
                { key: 'COMPLETED', label: '已完结', icon: 'fa-check-circle' },
                { key: 'ISSUES', label: '异常/停工', icon: 'fa-triangle-exclamation' },
            ].map(tab => (
                <button
                    key={tab.key}
                    onClick={() => setFilterStatus(tab.key)}
                    className={`px-6 py-4 text-sm font-bold flex items-center gap-2 transition border-b-2 ${
                        filterStatus === tab.key 
                        ? 'border-municipal-600 text-municipal-600 bg-white' 
                        : 'border-transparent text-slate-500 hover:text-slate-700 hover:bg-slate-100'
                    }`}
                >
                    <i className={`fa-solid ${tab.icon}`}></i> {tab.label}
                </button>
            ))}
        </div>

        {/* List Content */}
        <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
                <thead>
                    <tr className="bg-slate-50 text-slate-500 text-xs font-bold uppercase tracking-wider">
                        <th className="p-4 w-20">ID</th>
                        <th className="p-4">工程名称 / 地点</th>
                        <th className="p-4 w-32">类型</th>
                        <th className="p-4 w-32">当前状态</th>
                        <th className="p-4 w-24">优先级</th>
                        <th className="p-4 w-32">预算金额</th>
                        <th className="p-4 w-40">工程进度</th>
                        <th className="p-4 w-20 text-right">操作</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                    {filteredProjects.length === 0 ? (
                        <tr>
                            <td colSpan={8} className="p-12 text-center text-slate-400">
                                <i className="fa-solid fa-folder-open text-4xl mb-4 text-slate-200"></i>
                                <p>没有找到符合条件的项目</p>
                            </td>
                        </tr>
                    ) : (
                        filteredProjects.map((project) => (
                            <tr 
                                key={project.id} 
                                onClick={() => navigate(`/projects/${project.id}`)}
                                className="hover:bg-blue-50/50 transition cursor-pointer group"
                            >
                                <td className="p-4 text-xs font-mono text-slate-400">{project.id.split('-')[1]}</td>
                                <td className="p-4">
                                    <div className="font-bold text-slate-800 group-hover:text-municipal-600 transition">{project.title}</div>
                                    <div className="text-xs text-slate-500 mt-1 flex items-center gap-1">
                                        <i className="fa-solid fa-location-dot"></i> {project.location}
                                    </div>
                                </td>
                                <td className="p-4 text-sm text-slate-600">{TYPE_LABELS[project.type]}</td>
                                <td className="p-4">
                                    <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${STATUS_COLORS[project.status]}`}>
                                        {STATUS_LABELS[project.status]}
                                    </span>
                                </td>
                                <td className="p-4">
                                     <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${PRIORITY_COLORS[project.priority]}`}>
                                        {PRIORITY_LABELS[project.priority]}
                                    </span>
                                </td>
                                <td className="p-4 text-sm font-mono text-slate-700">¥{project.budget.toLocaleString()}</td>
                                <td className="p-4">
                                    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                                        <div 
                                            className={`h-full ${project.status === ProjectStatus.IN_PROGRESS ? 'bg-municipal-500' : 'bg-slate-300'}`} 
                                            style={{ width: `${project.progress}%` }}
                                        ></div>
                                    </div>
                                    <div className="text-xs text-right text-slate-400 mt-1 font-mono">{project.progress}%</div>
                                </td>
                                <td className="p-4 text-right">
                                    <button className="w-8 h-8 rounded-full bg-white border border-slate-200 text-slate-400 hover:text-municipal-600 hover:border-municipal-300 flex items-center justify-center transition shadow-sm">
                                        <i className="fa-solid fa-chevron-right"></i>
                                    </button>
                                </td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>
        </div>
        <div className="p-4 border-t border-slate-100 bg-slate-50 text-xs text-slate-500 flex justify-between items-center">
            <span>共找到 {filteredProjects.length} 个项目</span>
            <div className="flex gap-2">
                <button className="px-2 py-1 bg-white border rounded hover:bg-slate-100" disabled>上一页</button>
                <button className="px-2 py-1 bg-white border rounded hover:bg-slate-100">1</button>
                <button className="px-2 py-1 bg-white border rounded hover:bg-slate-100" disabled>下一页</button>
            </div>
        </div>
      </div>

      {/* 3. Charts Section (Collapsible or Secondary) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Status Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-bold text-slate-800">数据分析：状态分布</h3>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  fill="#8884d8"
                  paddingAngle={5}
                  dataKey="value"
                  label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
                <Legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Type Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
           <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-bold text-slate-800">数据分析：工程类型</h3>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={typeData} margin={{top: 10, right: 30, left: 0, bottom: 0}}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{fontSize: 12}} />
                <YAxis tick={{fontSize: 12}} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Bar dataKey="count" fill="#3b82f6" name="数量" radius={[4, 4, 0, 0]} barSize={20} />
                <Bar dataKey="budget" fill="#10b981" name="预算" radius={[4, 4, 0, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};