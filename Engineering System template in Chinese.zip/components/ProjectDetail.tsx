
import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
    Project, UserRole, ProjectStatus, TYPE_LABELS, STATUS_LABELS, PRIORITY_LABELS, 
    STATUS_COLORS, PRIORITY_COLORS 
} from '../types';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';

interface ProjectDetailProps {
    projects: Project[];
    currentUser: any;
    onUpdateProject: (id: string, updates: Partial<Project>) => void;
}

export const ProjectDetail: React.FC<ProjectDetailProps> = ({ projects, currentUser, onUpdateProject }) => {
    const { id } = useParams();
    const navigate = useNavigate();
    const project = projects.find(p => p.id === id);
    const [activeTab, setActiveTab] = useState('OVERVIEW');

    if (!project) {
        return (
            <div className="flex flex-col items-center justify-center h-full text-slate-400">
                <i className="fa-solid fa-folder-open text-6xl mb-4"></i>
                <p>未找到该项目信息</p>
                <button onClick={() => navigate('/projects')} className="mt-4 text-municipal-600 font-bold hover:underline">返回列表</button>
            </div>
        );
    }

    const isCitizen = currentUser.role === UserRole.CITIZEN;
    const isAdmin = currentUser.role === UserRole.ADMIN;
    
    // --- Actions ---
    const handleApprove = () => onUpdateProject(project.id, { status: ProjectStatus.APPROVED });
    const handleReject = () => onUpdateProject(project.id, { status: ProjectStatus.REJECTED });
    const handleStart = () => onUpdateProject(project.id, { status: ProjectStatus.IN_PROGRESS });
    const handleComplete = () => onUpdateProject(project.id, { status: ProjectStatus.COMPLETED });

    // --- Tab Content Renderers ---

    const renderOverview = () => (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 animate-fade-in">
            {/* Left: Info Card */}
            <div className="md:col-span-2 space-y-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                    <h3 className="font-bold text-slate-800 mb-4 border-b pb-2">工程概况</h3>
                    <p className="text-slate-600 leading-relaxed mb-4">{project.description}</p>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                            <span className="text-slate-400 block mb-1">施工地点</span>
                            <span className="font-bold text-slate-800">{project.location}</span>
                        </div>
                        <div>
                            <span className="text-slate-400 block mb-1">工程类型</span>
                            <span className="font-bold text-slate-800">{TYPE_LABELS[project.type]}</span>
                        </div>
                        <div>
                            <span className="text-slate-400 block mb-1">申请单位/人</span>
                            <span className="font-bold text-slate-800">{project.applicantName}</span>
                        </div>
                        <div>
                            <span className="text-slate-400 block mb-1">申请时间</span>
                            <span className="font-bold text-slate-800">{new Date(project.createdAt).toLocaleDateString()}</span>
                        </div>
                    </div>
                </div>

                {/* Progress Visualizer */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                    <h3 className="font-bold text-slate-800 mb-4 flex justify-between items-center">
                        当前进度
                        <span className="text-municipal-600 text-xl">{project.progress}%</span>
                    </h3>
                    <div className="w-full bg-slate-100 rounded-full h-4 overflow-hidden mb-6">
                        <div className="h-full bg-municipal-500 shadow-lg relative" style={{width: `${project.progress}%`}}>
                            <div className="absolute top-0 right-0 bottom-0 w-full bg-gradient-to-l from-white/20 to-transparent"></div>
                        </div>
                    </div>
                    
                    <div className="relative border-l-2 border-slate-200 ml-3 space-y-8 pb-4">
                        {project.milestones.length === 0 && <p className="text-slate-400 text-sm pl-6">暂无里程碑数据</p>}
                        {project.milestones.map((m, idx) => (
                            <div key={idx} className="relative pl-6">
                                <div className={`absolute -left-[9px] top-1 w-4 h-4 rounded-full border-2 ${m.status === 'COMPLETED' ? 'bg-municipal-500 border-municipal-500' : 'bg-white border-slate-300'}`}></div>
                                <h4 className={`text-sm font-bold ${m.status === 'COMPLETED' ? 'text-slate-800' : 'text-slate-500'}`}>{m.name}</h4>
                                <p className="text-xs text-slate-400">{m.date}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Right: Actions & Stats */}
            <div className="space-y-6">
                {/* Admin/Staff Actions */}
                {!isCitizen && (
                    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                        <h3 className="font-bold text-slate-800 mb-4">管理操作</h3>
                        <div className="space-y-3">
                            {project.status === ProjectStatus.PENDING && isAdmin && (
                                <>
                                    <button onClick={handleApprove} className="w-full py-3 bg-municipal-600 text-white rounded-lg font-bold hover:bg-municipal-700 shadow-md">
                                        <i className="fa-solid fa-stamp mr-2"></i> 批准立项
                                    </button>
                                    <button onClick={handleReject} className="w-full py-3 bg-slate-100 text-slate-600 rounded-lg font-bold hover:bg-slate-200">
                                        <i className="fa-solid fa-ban mr-2"></i> 驳回申请
                                    </button>
                                </>
                            )}
                            {project.status === ProjectStatus.APPROVED && (
                                <button onClick={handleStart} className="w-full py-3 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700 shadow-md">
                                    <i className="fa-solid fa-play mr-2"></i> 开始施工
                                </button>
                            )}
                            {project.status === ProjectStatus.IN_PROGRESS && (
                                <>
                                    <button onClick={() => onUpdateProject(project.id, {progress: Math.min(100, project.progress + 10)})} className="w-full py-2 border border-municipal-200 text-municipal-700 rounded-lg font-bold hover:bg-municipal-50">
                                        <i className="fa-solid fa-forward-step mr-2"></i> 更新进度 (+10%)
                                    </button>
                                    <button onClick={handleComplete} className="w-full py-2 bg-emerald-600 text-white rounded-lg font-bold hover:bg-emerald-700 shadow-md">
                                        <i className="fa-solid fa-check-circle mr-2"></i> 竣工验收
                                    </button>
                                </>
                            )}
                            <p className="text-xs text-slate-400 text-center mt-2">操作将记录在审计日志中</p>
                        </div>
                    </div>
                )}

                <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                    <h3 className="font-bold text-slate-800 mb-4">财务摘要</h3>
                    <div className="space-y-4">
                        <div>
                            <div className="flex justify-between text-sm mb-1">
                                <span className="text-slate-500">总预算</span>
                                <span className="font-mono font-bold">¥{project.budget.toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between text-sm mb-1">
                                <span className="text-slate-500">已支出</span>
                                <span className="font-mono font-bold text-orange-600">¥{project.spent.toLocaleString()}</span>
                            </div>
                            <div className="w-full bg-slate-100 rounded-full h-2 mt-2">
                                <div className="h-full bg-orange-400 rounded-full" style={{width: `${Math.min(100, (project.spent/project.budget)*100)}%`}}></div>
                            </div>
                            <p className="text-xs text-slate-400 text-right mt-1">预算执行率 {((project.spent/project.budget)*100).toFixed(1)}%</p>
                        </div>
                    </div>
                </div>

                {project.aiAnalysis && (
                    <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-6 rounded-xl border border-indigo-100">
                        <h3 className="font-bold text-indigo-900 mb-2 flex items-center gap-2">
                            <i className="fa-solid fa-robot"></i> AI 风险分析
                        </h3>
                        <div className="text-sm text-indigo-800 leading-relaxed" dangerouslySetInnerHTML={{__html: project.aiAnalysis}}></div>
                    </div>
                )}
            </div>
        </div>
    );

    const renderFinancials = () => (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden animate-fade-in">
            <div className="p-6 border-b flex justify-between items-center">
                <h3 className="font-bold text-slate-800">资金流水与合同</h3>
                {!isCitizen && <button className="text-sm bg-municipal-50 text-municipal-600 px-3 py-1 rounded font-bold">添加记录</button>}
            </div>
            <div className="p-6">
                {project.costs.length === 0 ? (
                    <p className="text-center text-slate-400 py-8">暂无财务记录</p>
                ) : (
                    <table className="w-full text-sm text-left">
                        <thead className="bg-slate-50 text-slate-500 font-bold">
                            <tr>
                                <th className="p-3">日期</th>
                                <th className="p-3">类型</th>
                                <th className="p-3">说明</th>
                                <th className="p-3 text-right">金额</th>
                            </tr>
                        </thead>
                        <tbody>
                            {project.costs.map((c, i) => (
                                <tr key={i} className="border-b last:border-0 hover:bg-slate-50">
                                    <td className="p-3">{c.date}</td>
                                    <td className="p-3"><span className="bg-slate-100 px-2 py-0.5 rounded text-xs">{c.category}</span></td>
                                    <td className="p-3">{c.description}</td>
                                    <td className="p-3 text-right font-mono font-bold">-¥{c.amount.toLocaleString()}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );

    return (
        <div className="space-y-6 max-w-7xl mx-auto pb-12">
            {/* Header / Cockpit Top */}
            <div className="bg-white p-6 rounded-xl shadow-sm border-l-4 border-municipal-500 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <div className="flex items-center gap-3 mb-1">
                        <h1 className="text-2xl font-extrabold text-slate-800">{project.title}</h1>
                        <span className={`px-3 py-1 rounded-full text-xs font-bold border ${STATUS_COLORS[project.status]}`}>
                            {STATUS_LABELS[project.status]}
                        </span>
                        <span className={`px-3 py-1 rounded-full text-xs font-bold border ${PRIORITY_COLORS[project.priority]}`}>
                            {PRIORITY_LABELS[project.priority]}
                        </span>
                    </div>
                    <p className="text-slate-500 text-sm flex items-center gap-4">
                        <span><i className="fa-solid fa-barcode mr-1"></i> ID: {project.id}</span>
                        <span><i className="fa-solid fa-user-tag mr-1"></i> 负责人: {project.assignedTo || '待分配'}</span>
                    </p>
                </div>
                <button onClick={() => navigate('/projects')} className="text-slate-400 hover:text-slate-600 font-bold text-sm">
                    <i className="fa-solid fa-arrow-left mr-1"></i> 返回台账
                </button>
            </div>

            {/* Navigation Tabs */}
            <div className="flex border-b border-slate-200 gap-6 px-2">
                <button 
                    onClick={() => setActiveTab('OVERVIEW')}
                    className={`pb-3 font-bold text-sm transition ${activeTab === 'OVERVIEW' ? 'text-municipal-600 border-b-2 border-municipal-600' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    总览驾驶舱
                </button>
                {!isCitizen && (
                    <>
                        <button 
                            onClick={() => setActiveTab('FINANCE')}
                            className={`pb-3 font-bold text-sm transition ${activeTab === 'FINANCE' ? 'text-municipal-600 border-b-2 border-municipal-600' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            资金与合同
                        </button>
                        <button 
                            onClick={() => setActiveTab('FILES')}
                            className={`pb-3 font-bold text-sm transition ${activeTab === 'FILES' ? 'text-municipal-600 border-b-2 border-municipal-600' : 'text-slate-500 hover:text-slate-700'}`}
                        >
                            图纸与文档
                        </button>
                    </>
                )}
            </div>

            {/* Tab Content */}
            <div className="min-h-[400px]">
                {activeTab === 'OVERVIEW' && renderOverview()}
                {activeTab === 'FINANCE' && renderFinancials()}
                {activeTab === 'FILES' && (
                    <div className="bg-white p-12 text-center text-slate-400 rounded-xl border border-slate-200">
                        <i className="fa-solid fa-file-pdf text-4xl mb-4"></i>
                        <p>文档管理模块建设中...</p>
                    </div>
                )}
            </div>
        </div>
    );
};
