import React, { useState } from 'react';
import { ProjectType, ProjectPriority, TYPE_LABELS, PRIORITY_LABELS } from '../types';

interface ProjectFormProps {
  onSubmit: (data: any) => void;
  onCancel: () => void;
}

export const ProjectForm: React.FC<ProjectFormProps> = ({ onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    title: '',
    type: ProjectType.ROADWORK,
    priority: ProjectPriority.NORMAL,
    budget: '',
    location: '',
    description: '',
    applicantName: '',
    applicantContact: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.title.trim()) newErrors.title = "请输入工程项目名称";
    if (!formData.location.trim()) newErrors.location = "请输入详细施工地点";
    if (!formData.applicantName.trim()) newErrors.applicantName = "请输入申请人/单位名称";
    if (!formData.applicantContact.trim()) newErrors.applicantContact = "请输入有效联系方式";
    if (formData.description.length < 10) newErrors.description = "工程描述不能少于10个字";
    if (Number(formData.budget) <= 0) newErrors.budget = "请输入有效的预算金额";
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit({
        ...formData,
        budget: Number(formData.budget)
      });
    }
  };

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-2xl overflow-hidden animate-fade-in border border-slate-200">
      <div className="bg-gradient-to-r from-municipal-900 to-municipal-800 px-8 py-8 relative overflow-hidden">
        <div className="absolute right-0 top-0 opacity-10 transform translate-x-10 -translate-y-10">
             <i className="fa-solid fa-helmet-safety text-9xl text-white"></i>
        </div>
        <h2 className="text-3xl font-bold text-white flex items-center gap-3 relative z-10">
          <i className="fa-solid fa-file-pen"></i>
          新建工程委托
        </h2>
        <p className="text-municipal-100 mt-2 relative z-10">智慧市政管理云平台 · 在线申报系统</p>
      </div>

      <form onSubmit={handleSubmit} className="p-8 space-y-8">
        {/* Basic Info Section */}
        <div>
          <h3 className="text-lg font-bold text-slate-800 border-b-2 border-slate-100 pb-3 mb-6 flex items-center">
            <span className="bg-municipal-500 w-2 h-6 rounded mr-2"></span>
            基础信息
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
            <div className="col-span-2">
              <label className="block text-sm font-bold text-slate-700 mb-2">工程项目名称 <span className="text-red-500">*</span></label>
              <input
                type="text"
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-municipal-500 outline-none transition bg-slate-50 focus:bg-white ${errors.title ? 'border-red-500 bg-red-50' : 'border-slate-300'}`}
                value={formData.title}
                onChange={e => setFormData({...formData, title: e.target.value})}
                placeholder="例如：朝阳路中段路面修缮工程"
              />
              {errors.title && <p className="text-red-500 text-xs mt-1 flex items-center"><i className="fa-solid fa-circle-exclamation mr-1"></i>{errors.title}</p>}
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">工程类型 <span className="text-red-500">*</span></label>
              <div className="relative">
                <select
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-municipal-500 outline-none appearance-none bg-slate-50"
                    value={formData.type}
                    onChange={e => setFormData({...formData, type: e.target.value as ProjectType})}
                >
                    {Object.values(ProjectType).map(t => (
                    <option key={t} value={t}>{TYPE_LABELS[t]}</option>
                    ))}
                </select>
                <div className="absolute right-4 top-3.5 text-slate-500 pointer-events-none">
                    <i className="fa-solid fa-chevron-down"></i>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">紧急程度/优先级 <span className="text-red-500">*</span></label>
              <div className="relative">
                <select
                    className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-municipal-500 outline-none appearance-none bg-slate-50"
                    value={formData.priority}
                    onChange={e => setFormData({...formData, priority: e.target.value as ProjectPriority})}
                >
                    {Object.values(ProjectPriority).map(p => (
                    <option key={p} value={p}>{PRIORITY_LABELS[p]}</option>
                    ))}
                </select>
                 <div className="absolute right-4 top-3.5 text-slate-500 pointer-events-none">
                    <i className="fa-solid fa-chevron-down"></i>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">预算估算 (人民币) <span className="text-red-500">*</span></label>
              <div className="relative">
                  <span className="absolute left-4 top-3 text-slate-500">¥</span>
                  <input
                    type="number"
                    min="0"
                    className={`w-full pl-8 pr-4 py-3 border rounded-lg focus:ring-2 focus:ring-municipal-500 outline-none transition bg-slate-50 ${errors.budget ? 'border-red-500' : 'border-slate-300'}`}
                    value={formData.budget}
                    onChange={e => setFormData({...formData, budget: e.target.value})}
                    placeholder="0.00"
                />
              </div>
              {errors.budget && <p className="text-red-500 text-xs mt-1">{errors.budget}</p>}
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">具体施工地点 <span className="text-red-500">*</span></label>
              <div className="relative">
                  <div className="absolute right-4 top-3 text-slate-400"><i className="fa-solid fa-location-dot"></i></div>
                  <input
                    type="text"
                    className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-municipal-500 outline-none transition bg-slate-50 ${errors.location ? 'border-red-500' : 'border-slate-300'}`}
                    value={formData.location}
                    onChange={e => setFormData({...formData, location: e.target.value})}
                    placeholder="街道地址或经纬度坐标"
                />
              </div>
               {errors.location && <p className="text-red-500 text-xs mt-1">{errors.location}</p>}
            </div>
          </div>
        </div>

        {/* Details */}
        <div>
             <label className="block text-sm font-bold text-slate-700 mb-2">工程描述与施工范围 <span className="text-red-500">*</span></label>
            <textarea
              rows={5}
              className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:ring-municipal-500 outline-none transition bg-slate-50 ${errors.description ? 'border-red-500' : 'border-slate-300'}`}
              value={formData.description}
              onChange={e => setFormData({...formData, description: e.target.value})}
              placeholder="请详细描述工程现状、施工需求、预期目标及周边环境情况..."
            />
            {errors.description && <p className="text-red-500 text-xs mt-1">{errors.description}</p>}
            <p className="text-slate-400 text-xs mt-2 text-right">{formData.description.length}/500 字</p>
        </div>

        {/* Applicant Section */}
        <div className="bg-slate-50 p-6 rounded-lg border border-slate-200">
          <h3 className="text-md font-bold text-slate-800 mb-4 flex items-center">
             <i className="fa-solid fa-id-card text-municipal-500 mr-2"></i> 申请人/单位信息
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">单位名称/申请人姓名 <span className="text-red-500">*</span></label>
              <input
                type="text"
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-municipal-500 outline-none transition bg-white ${errors.applicantName ? 'border-red-500' : 'border-slate-300'}`}
                value={formData.applicantName}
                onChange={e => setFormData({...formData, applicantName: e.target.value})}
              />
               {errors.applicantName && <p className="text-red-500 text-xs mt-1">{errors.applicantName}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">联系电话/邮箱 <span className="text-red-500">*</span></label>
              <input
                type="text"
                className={`w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-municipal-500 outline-none transition bg-white ${errors.applicantContact ? 'border-red-500' : 'border-slate-300'}`}
                value={formData.applicantContact}
                onChange={e => setFormData({...formData, applicantContact: e.target.value})}
              />
               {errors.applicantContact && <p className="text-red-500 text-xs mt-1">{errors.applicantContact}</p>}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 pt-4 border-t border-slate-100">
           <button
            type="submit"
            className="flex-1 bg-municipal-600 hover:bg-municipal-800 text-white font-bold py-4 px-6 rounded-lg transition-all shadow-lg hover:shadow-xl flex justify-center items-center gap-2 text-lg transform hover:-translate-y-1"
          >
            <i className="fa-solid fa-paper-plane"></i> 提交委托申请
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="px-8 py-4 border border-slate-300 text-slate-600 font-semibold rounded-lg hover:bg-slate-100 transition"
          >
            取消
          </button>
        </div>
      </form>
    </div>
  );
};