import { GoogleGenAI } from "@google/genai";
import { Project, ProjectType, User, TYPE_LABELS } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeProjectRisk = async (
  title: string,
  description: string,
  type: ProjectType,
  budget: number
): Promise<string> => {
  if (!process.env.API_KEY) {
    return "<p class='text-red-500'>AI 分析服务不可用：未配置 API 密钥。</p>";
  }

  try {
    const typeName = TYPE_LABELS[type];
    const prompt = `
      你是一位资深的市政工程监理专家。请针对以下工程委托进行风险与可行性分析：
      
      工程名称：${title}
      工程类型：${typeName}
      预算估算：¥${budget}
      工程描述：${description}

      请提供一份专业的简报（约 200 字），必须包含以下三个部分：
      1. **风险评估**：评估施工难度、周边影响及潜在风险等级（低/中/高）。
      2. **资源建议**：建议需要调配的关键机械设备或特殊资质人员。
      3. **合规提示**：针对该类型工程的市政合规性或环保注意事项。
      
      输出格式要求：请直接返回一段简洁美观的 HTML 代码（使用 <div>, <h4>, <ul>, <li>, <span class="text-red-600"> 等标签来强调关键信息），不要包含 markdown 标记，不要包含 <html> 或 <body> 标签。风格要严肃、专业。
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "无法生成分析报告。";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "生成 AI 分析时发生错误，请稍后重试。";
  }
};

export const suggestAssignment = async (project: Project, staffList: User[]): Promise<string> => {
    if (!process.env.API_KEY) return "AI 建议服务不可用。";

    try {
        const staffString = staffList.map(s => `- ${s.name} (${s.department || '通用部门'})`).join('\n');
        const typeName = TYPE_LABELS[project.type];
        
        const prompt = `
            基于工程 "${project.title}" (类型: ${typeName}) 的需求，从以下员工列表中选择最合适的人选：
            ${staffString}
            
            请直接回答：推荐谁？并用一句话简述理由（例如：“推荐张三，因为他在排水工程方面经验丰富”）。
        `;

         const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt,
        });

        return response.text || "暂无推荐建议。";
    } catch (e) {
        return "无法获取建议。";
    }
}